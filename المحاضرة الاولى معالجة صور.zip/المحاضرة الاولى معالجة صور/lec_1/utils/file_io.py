# utils/file_io.py
import os
from datetime import datetime


def save_txt(file_name: str, content: str, folder: str = "outputs", mode: str = "a",
             encoding: str = "utf-8") -> str:
    """
    يحفظ المحتوى النصي في ملف داخل مجلد `outputs/`.

    Parameters
    ----------
    file_name : str
        اسم الملف بدون الامتداد (أو مع .txt إن أحببت).
    content : str
        النص المراد كتابته.
    folder : str, optional
        اسم المجلد الذي سيُحفَظ فيه الملف. افتراضي: "outputs".
    mode : str, optional
        وضعية الفتح: "a" للإلحاق أو "w" للكتابة من جديد. افتراضي: "a".
    encoding : str, optional
        ترميز الملف. افتراضي: "utf-8".

    Returns
    -------
    str
        المسار الكامل للملف الذي تم إنشاؤه/تعديله.
    """
    # تأكد من وجود المجلد
    os.makedirs(folder, exist_ok=True)

    # تأكد من إضافة الامتداد
    if not file_name.endswith(".txt"):
        file_name += ".txt"

    file_path = os.path.join(folder, file_name)

    # أضف طابعاً زمنياً بسيطاً (اختياري)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    content_to_write = f"[{timestamp}]\n{content}\n{'-' * 40}\n"

    # اكتب/ألحِق المحتوى
    with open(file_path, mode, encoding=encoding) as f:
        f.write(content_to_write)

    return file_path
