# scripts/image_demo.py
import cv2
import matplotlib.pyplot as plt
import sys
from pathlib import Path

# أضف مجلد lec_1 إلى sys.path
BASE_DIR = Path(__file__).resolve().parent.parent  # parent == lec_1
sys.path.append(str(BASE_DIR))
from utils.file_io import save_txt

def read_and_display_image(image:str, log_file: str = "image_info") -> None:
    """
    يقرأ الصورة، يطبع معلوماتها، يعرضها، ثم يحفظ نفس المعلومات في ملف نصي.
    """
    image = cv2.imread(image)
    print(image)
    if image is None:
        msg = f"❌ لم يتم العثور على الصورة: {image}"
        print(msg)
        save_txt(log_file, msg)      # نسجّل الخطأ في ملف السجل أيضاً
        return

    # معالجة وتحويل الألوان
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    height, width, channels = image.shape
    info_lines = [
        "📊 معلومات الصورة:",
        f"المسار       : {image}",
        f"الارتفاع     : {height} بكسل",
        f"العرض        : {width} بكسل",
        f"عدد القنوات  : {channels}",
        f"نوع البيانات : {image.dtype}",
        f"حجم الذاكرة  : {image.nbytes / 1024:.2f} KB",
    ]
    info_text = "\n".join(info_lines)

    # طباعة على الطرفية

    # حفظ في ملف نصي
    save_txt(log_file, info_text)

    # عرض الصورة
    plt.figure(figsize=(10, 6))
    plt.imshow(image_rgb)
    plt.title(f'الصورة الأصلية – {width}×{height}')
    plt.axis('off')
    plt.show()


if __name__ == "__main__":
    img_path = "../images/image1.jpeg"   # غيّر المسار حسب الحاجة
    read_and_display_image(img_path, log_file="img1_details")
