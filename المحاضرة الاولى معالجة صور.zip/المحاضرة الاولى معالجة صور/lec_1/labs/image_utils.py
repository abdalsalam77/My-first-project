
# lec_1/labs/image_utils.py  (أو في ملفك الحالي)
import cv2
import numpy as np
import matplotlib.pyplot as plt
import sys
from pathlib import Path

# أضف مجلد lec_1 إلى sys.path
BASE_DIR = Path(__file__).resolve().parent.parent  # parent == lec_1
sys.path.append(str(BASE_DIR))
from utils.file_io import save_txt  # تأكد من مسار الاستيراد الصحيح


def image_types_conversion(image: np.ndarray, *, log_file: str = "image_stats") -> dict:
    """
    يحوّل الصورة إلى Gray, Binary, HSV، يعرض النتائج، ويُسجّل الإحصاءات في ملف نصّي.

    Parameters
    ----------
    image : np.ndarray
        الصورة بـصيغة RGB (وليس BGR).
    log_file : str, optional
        اسم ملف السجّل داخل مجلد outputs/ (بدون .txt). افتراضي: "image_stats".

    Returns
    -------
    dict
        إحصائيات سريعة يمكن إعادة استخدامها في مكان آخر.
    """
    if image is None:
        msg = "❌ الصورة غير متوفرة"
        print(msg)
        save_txt(log_file, msg)
        return {}

    image=cv2.imread(image)
    # 1️⃣ Gray
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    print("gray shape:", gray.shape)


    # 2️⃣ Binary (عتبة 127)
    _, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
    print(binary)

    # 3️⃣ HSV
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    hsv_rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)  # للعرض فقط

    # ——— عرض النواتج ———
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    axes[0, 0].imshow(image);
    axes[0, 0].set_title('الصورة الأصلية (RGB)');
    axes[0, 0].axis('off')
    axes[0, 1].imshow(gray, cmap='gray');
    axes[0, 1].set_title('رمادية (Gray)');
    axes[0, 1].axis('off')
    axes[1, 0].imshow(binary, cmap='gray');
    axes[1, 0].set_title('ثنائية (Binary)');
    axes[1, 0].axis('off')
    axes[1, 1].imshow(hsv_rgb);
    axes[1, 1].set_title('نموذج HSV');
    axes[1, 1].axis('off')
    plt.tight_layout();
    plt.show()

    # ——— حساب الإحصاءات ———
    stats = {
        "متوسط_السطوع": float(np.mean(gray)),
        "أقل_قيمة": int(np.min(gray)),
        "أعلى_قيمة": int(np.max(gray)),
        "عدد_البكسل_البيضاء": int(np.sum(binary == 255)),
        "عدد_البكسل_السوداء": int(np.sum(binary == 0)),
    }

    # ️— حفظها في ملف —
    lines = [f"{k.replace('_', ' ')}: {v}" for k, v in stats.items()]
    save_txt(log_file, "\n".join(lines))

    # طباعة ودّيّة
    print("📊 إحصائيات سريعة:")
    for k, v in stats.items():
        print(f"   {k.replace('_', ' ')}: {v}")

    return stats


if __name__ == "__main__":
    img_path = "../images/image1.jpeg"
    stats = image_types_conversion(img_path, log_file="image1_stats")
    print(stats)