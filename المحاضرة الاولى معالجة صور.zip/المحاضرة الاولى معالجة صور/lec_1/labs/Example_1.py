# تثبيت المكتبات (في Terminal/Command Prompt)
# pip install opencv-python
# pip install matplotlib
# pip install numpy
# pip install pillow
# pip install jupyter

# الاستيراد في Python
import cv2                    # مكتبة OpenCV الرئيسية
import numpy as np           # العمليات الرياضية على المصفوفات
import matplotlib.pyplot as plt  # عرض الصور والرسوم البيانية
from PIL import Image        # Python Imaging Library
import os                    # التعامل مع الملفات

