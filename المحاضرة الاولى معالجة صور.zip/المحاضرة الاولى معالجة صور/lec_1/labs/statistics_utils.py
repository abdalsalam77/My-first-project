# lec_1/labs/statistics_utils.py
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import sys
from pathlib import Path

# أضف مجلد lec_1 إلى sys.path
BASE_DIR = Path(__file__).resolve().parent.parent  # parent == lec_1
sys.path.append(str(BASE_DIR))
from utils.file_io import save_txt   # تأكد من المسار الصحيح

def image_statistics(
    image: np.ndarray,
    *,
    log_file: str = "image_stats",
    save_hist: bool = True
) -> dict:
    """
    يحسب إحصاءات شاملة للصورة (Gray-scale)، يطبعها، يحفظها، ويرجعها.

    Parameters
    ----------
    image : np.ndarray
        مصفوفة RGB (أو BGR بعد التحويل إلى RGB مسبقاً).
    log_file : str, optional
        اسم ملف السجّل داخل مجلد outputs/ (بدون .txt). افتراضي "image_stats".
    save_hist : bool
        إذا True يُحفَظ الـ Histogram كصورة PNG في outputs/plots/.

    Returns
    -------
    dict
        جميع الإحصاءات المحسوبة.
    """
    if image is None:
        msg = "❌ الصورة غير متوفرة"
        print(msg)
        save_txt(log_file, msg)
        return {}

    # ——— تحويل إلى رمادي ———
    image=cv2.imread(image)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # ——— حساب الإحصاءات ———
    stats = {
        "mean": float(np.mean(gray)),
        "std": float(np.std(gray)),
        "min": int(np.min(gray)),
        "max": int(np.max(gray)),
        "median": float(np.median(gray)),
    }

    # توزيع السطوع
    dark      = int(np.sum(gray < 85))
    medium    = int(np.sum((gray >= 85) & (gray < 170)))
    bright    = int(np.sum(gray >= 170))
    total_pix = int(gray.size)
    stats.update({
        "total_pixels": total_pix,
        "dark_pixels": dark,
        "medium_pixels": medium,
        "bright_pixels": bright,
        "dark_percent":   dark   / total_pix * 100,
        "medium_percent": medium / total_pix * 100,
        "bright_percent": bright / total_pix * 100,
    })

    # ——— تصنيف عام ———
    if stats["mean"] < 85:
        stats["image_type"] = "صورة داكنة 🌙"
    elif stats["mean"] > 170:
        stats["image_type"] = "صورة فاتحة ☀️"
    else:
        stats["image_type"] = "صورة متوازنة ⚖️"

    # ——— طباعة ودّيّة ———
    print("📊 تحليل إحصائي شامل للصورة:")
    print("=" * 50)
    print(f"المتوسط (Mean): {stats['mean']:.2f}")
    print(f"الانحراف المعياري (Std): {stats['std']:.2f}")
    print(f"أقل قيمة (Min): {stats['min']}")
    print(f"أعلى قيمة (Max): {stats['max']}")
    print(f"الوسيط (Median): {stats['median']:.2f}")
    print(f"إجمالي البكسلات: {stats['total_pixels']:,}")
    print()
    print("🎨 توزيع السطوع:")
    print(f"بكسلات داكنة  (0-84)  : {dark:,} ({stats['dark_percent']:.1f}%)")
    print(f"بكسلات متوسطة (85-169): {medium:,} ({stats['medium_percent']:.1f}%)")
    print(f"بكسلات فاتحة  (170-255): {bright:,} ({stats['bright_percent']:.1f}%)")
    print(f"\n🏷️ تصنيف الصورة: {stats['image_type']}")

    # ——— حفظ السجل النصّي ———
    txt_lines = [
        "📊 إحصائيات الصورة:",
        f"التاريخ       : {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"المتوسط       : {stats['mean']:.2f}",
        f"الانحراف المعياري : {stats['std']:.2f}",
        f"أقل قيمة      : {stats['min']}",
        f"أعلى قيمة     : {stats['max']}",
        f"الوسيط        : {stats['median']:.2f}",
        f"إجمالي البكسلات   : {stats['total_pixels']:,}",
        "",
        "🎨 توزيع السطوع:",
        f"داكنة   : {dark:,} ({stats['dark_percent']:.1f}%)",
        f"متوسطة  : {medium:,} ({stats['medium_percent']:.1f}%)",
        f"فاتحة   : {bright:,} ({stats['bright_percent']:.1f}%)",
        f"",
        f"🏷️ تصنيف: {stats['image_type']}",
    ]
    save_txt(log_file, "\n".join(txt_lines))

    # ——— رسم Histogram وحفظه إن طُلب ———
    if save_hist:
        os.makedirs("outputs/plots", exist_ok=True)

        plt.figure(figsize=(8, 4))
        plt.hist(gray.flatten(), bins=50, alpha=0.7)   # بدون ألوان محدَّدة
        plt.axvline(stats["mean"],   linestyle="--", label=f'Mean {stats["mean"]:.1f}')
        plt.axvline(stats["median"], linestyle="--", label=f'Median {stats["median"]:.1f}')
        plt.title("Brightness Histogram")
        plt.xlabel("Gray Value")
        plt.ylabel("Pixel Count")
        plt.legend()
        plt.grid(True, alpha=0.3)

        hist_path = f"outputs/plots/{log_file}_hist.png"
        plt.tight_layout()
        plt.savefig(hist_path, dpi=120)
        plt.show()

        print(f"📈 حُفِظ مخطط Histogram في: {hist_path}")

    return stats


if __name__ == "__main__":
    img_path = "../images/image1.jpeg"

    stats = image_statistics(img_path, log_file="img1_full_stats")
    print("\n✅ الإحصاءات مخزَّنة في outputs/img1_full_stats.txt")