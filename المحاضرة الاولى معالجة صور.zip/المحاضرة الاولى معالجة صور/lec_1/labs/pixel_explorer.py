# lec_1/labs/pixel_explorer.py
import cv2
import matplotlib.pyplot as plt
import numpy as np

import sys
from pathlib import Path

# أضف مجلد lec_1 إلى sys.path
BASE_DIR = Path(__file__).resolve().parent.parent  # parent == lec_1
sys.path.append(str(BASE_DIR))
from utils.file_io import save_txt   # حدِّث المسار إذا لزم

def explore_image_pixels(
    image: np.ndarray,
    *,                     # تجعل كل ما بعده معاملات مسمّاة
    log_file: str = "pixel_values",
    annotate: bool = True,
    points: list[tuple[int, int]] | None = None
) -> list[dict]:
    """
    يستكشف قيم البكسلات في نقاط مختارة، يطبعها، يحفظها، ويُرجِعها.

    Parameters
    ----------
    image : np.ndarray
        مصفوفة RGB أو Grayscale.
    log_file : str
        اسم ملف السجل داخل مجلد outputs/ (بدون .txt).
    annotate : bool
        هل تُظهِر النقاط على الصورة؟
    points : list[tuple[int, int]] | None
        نقاط مخصّصة (x, y). إذا None تُختار نقاط افتراضية.

    Returns
    -------
    list[dict]
        قائمة معجمية بالقيم الملتقطة.
    """
    if image is None:
        msg = "❌ الصورة غير متوفرة"
        print(msg)
        save_txt(log_file, msg)
        return []
    image=cv2.imread(image)
    h, w,_ = image.shape

    # نقاط افتراضية إن لم تُمرَّر
    if points is None:
        points = [
            (0, 0), (w // 2, h // 2), (w - 1, h - 1),
            (w // 4, h // 4), (3 * w // 4, 3 * h // 4)
        ]

    # ——— معالجة القيم ———
    content_lines = ["🔍 استكشاف قيم البكسلات:", "-" * 40]
    results = []

    for i, (x, y) in enumerate(points, 1):
        pixel = image[y, x]        # (y, x) في NumPy
        entry = {"index": i, "x": x, "y": y}

        if pixel.ndim == 0 or pixel.shape == ():  # صورة رمادية من قناة واحدة
            gray_val = int(pixel)
            entry["gray"] = gray_val
            line = f"{i}) ({x}, {y}) → Gray: {gray_val}"
        else:                                   # ملونة
            r, g, b = map(int, pixel)
            entry.update({"r": r, "g": g, "b": b})
            dominant = max(("أحمر", r), ("أخضر", g), ("أزرق", b),
                           key=lambda t: t[1])[0]
            entry["dominant"] = dominant
            line = f"{i}) ({x}, {y}) → R:{r} G:{g} B:{b} ✦ سائد: {dominant}"

        content_lines.append(line)
        results.append(entry)

        # طباعة فورية
        print(line)

    # ——— حفظ في ملف نصي ———
    save_txt(log_file, "\n".join(content_lines))

    # ——— عرض مع التعليقات ———
    if annotate:
        img_vis = image.copy()
        if img_vis.ndim == 2:                   # رمادية → إلى RGB للعَرض
            img_vis = cv2.cvtColor(img_vis, cv2.COLOR_GRAY2RGB)

        for x, y in points:
            cv2.circle(img_vis, (x, y), radius=6, color=(255, 0, 0), thickness=-1)

        plt.figure(figsize=(8, 6))
        plt.imshow(img_vis)
        plt.title("نقاط العيّنة (بالأحمر)")
        plt.axis("off")
        plt.show()

    return results


if __name__ == "__main__":
    img_path = "../images/image1.jpeg"
    explore_image_pixels(img_path, log_file="img1_pixels")
