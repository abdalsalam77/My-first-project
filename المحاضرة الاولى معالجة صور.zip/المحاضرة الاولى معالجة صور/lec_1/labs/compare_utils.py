# lec_1/labs/compare_utils.py
import os
from datetime import datetime

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity as ssim  # SSIM
import sys
from pathlib import Path

# أضف مجلد lec_1 إلى sys.path
BASE_DIR = Path(__file__).resolve().parent.parent  # parent == lec_1
sys.path.append(str(BASE_DIR))
from utils.file_io import save_txt   # عدّل المسار إذا لزم

def compare_two_images(
    image1_path: str,
    image2_path: str,
    *,
    log_file: str = "image_compare",
    save_plots: bool = True
) -> dict:
    """
    مقارنة شاملة بين صورتين:
    - تحجيم آلي لأصغر مشترك
    - خريطة اختلاف + Histogram
    - SSIM + مقياس الاختلاف البسيط
    - حفظ تقرير وصور في مجلد outputs/

    Returns
    -------
    dict
        جميع القياسات لتوظيفها لاحقاً.
    """

    # ——— قراءة وتحويل إلى RGB ———
    img1 = cv2.imread(image1_path)
    img2 = cv2.imread(image2_path)
    if img1 is None or img2 is None:
        msg = "❌ خطأ في قراءة إحدى الصورتين"
        print(msg);  save_txt(log_file, msg);  return {}

    img1_rgb = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
    img2_rgb = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
    print("img1_rgb : {}".format(img1_rgb.shape))
    print("img2_rgb : {}".format(img2_rgb.shape))
    # ——— تحجيم لأصغر أبعاد مشتركة ———
    h = min(img1_rgb.shape[0], img2_rgb.shape[0])
    w = min(img1_rgb.shape[1], img2_rgb.shape[1])
    print("h : {}".format(h))
    print("w : {}".format(w))

    img1_rs = cv2.resize(img1_rgb, (w, h))
    img2_rs = cv2.resize(img2_rgb, (w, h))
    print("img1_rs : {}".format(img1_rs.shape))
    print("img2_rs : {}".format(img2_rs.shape))
    gray1 = cv2.cvtColor(img1_rs, cv2.COLOR_RGB2GRAY)
    gray2 = cv2.cvtColor(img2_rs, cv2.COLOR_RGB2GRAY)

    # ——— حساب الفروق ———
    diff      = cv2.absdiff(gray1, gray2)
    print("diff : {}".format(diff.shape))
    mean1     = np.mean(gray1)
    print("mean1 : {}".format(mean1))
    mean2     = np.mean(gray2)
    print("mean2 : {}".format(mean2))
    mean_diff = np.mean(diff)
    print("mean_diff : {}".format(mean_diff))
    max_diff  = int(np.max(diff))
    print("max_diff : {}".format(max_diff))

    # SSIM (كلما اقترب من 1 كان التشابه أكبر)
    ssim_score = ssim(gray1, gray2)
    print("ssim_score : {}".format(ssim_score))

    # تقييم بسيط كنسبة مئوية
    simple_similarity = 100 - (mean_diff / 255 * 100)

    # ——— رسم النتائج ———
    if save_plots:
        os.makedirs("outputs/plots", exist_ok=True)

        # 1) عرض / حفظ الشكل الرباعي
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        axes[0, 0].imshow(img1_rs); axes[0, 0].set_title(f"الصورة 1 (Mean={mean1:.1f})"); axes[0, 0].axis('off')
        axes[0, 1].imshow(img2_rs); axes[0, 1].set_title(f"الصورة 2 (Mean={mean2:.1f})"); axes[0, 1].axis('off')
        axes[1, 0].imshow(diff, cmap='hot'); axes[1, 0].set_title(f"خريطة الاختلاف (Mean={mean_diff:.1f})"); axes[1, 0].axis('off')
        axes[1, 1].hist(gray1.flatten(), bins=50, alpha=.7, label='صورة 1')
        axes[1, 1].hist(gray2.flatten(), bins=50, alpha=.7, label='صورة 2')
        axes[1, 1].set_title("Histogram السطوع"); axes[1, 1].legend(); axes[1, 1].grid(alpha=.3)
        plt.tight_layout()

        plot_path = f"outputs/plots/{log_file}_panel.png"
        plt.savefig(plot_path, dpi=120)
        plt.show()

        # 2) احفظ خريطة الاختلاف منفردة لو أردت
        diff_path = f"outputs/plots/{log_file}_diff.png"
        plt.imsave(diff_path, diff, cmap='hot')

    # ——— تقرير نصّي ———
    txt_lines = [
        "📋 تقرير مقارنة صورتين",
        f"التاريخ     : {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"المسار 1    : {image1_path}",
        f"المسار 2    : {image2_path}",
        f"حجم 1       : {img1.shape}",
        f"حجم 2       : {img2.shape}",
        f"Mean Gray 1 : {mean1:.2f}",
        f"Mean Gray 2 : {mean2:.2f}",
        f"Mean Diff   : {mean_diff:.2f}",
        f"Max Diff    : {max_diff}",
        f"SSIM        : {ssim_score:.3f}",
        f"تشابه بسيط  : {simple_similarity:.1f} %",
    ]
    save_txt(log_file, "\n".join(txt_lines))

    # ——— طباعة مختصرة للمستخدم ———
    print("\n".join(txt_lines))
    verdict = ("✅ متطابقتان تقريباً"  if simple_similarity > 90 else
               "🟡 متشابهتان جزئياً" if simple_similarity > 70 else
               "❌ مختلفتان بوضوح")
    print(f"\n{verdict}")

    # ——— رجوع النتائج ———
    return {
        "w": w, "h": h,
        "mean1": mean1, "mean2": mean2,
        "mean_diff": mean_diff, "max_diff": max_diff,
        "simple_similarity": simple_similarity,
        "ssim": ssim_score,
        "panel_path": plot_path if save_plots else None,
        "diff_path": diff_path if save_plots else None,
        "log_path": f"outputs/{log_file}.txt"
    }


if __name__ == "__main__":
    img_path1 = "../images/img_test1.png"
    img_path2 = "../images/img_test2.png"
    stats = compare_two_images(img_path1, img_path2,
                               log_file="img1_vs_img2")
    print("\n🔑 SSIM =", stats["ssim"])